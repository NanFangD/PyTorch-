"""
-*- coding: utf-8 -*-
@Time :  2022-04-01 22:19
@Author : nanfang
"""
import random

import numpy as np

# 将数据按照标签分类
def classify(data, labels):
    data2 = [[] for i in range(0, 10)]
    for i in range(0, len(data)):
        data2[labels[i]].append(data[i])
    return data2


# 核函数，采用线性函数
def kernel(data, line):
    x, y = np.shape(data)
    K = np.dot(data, line)
    return K


# 存放SMO相关参数
class SMO_my():
    def __init__(self, data, labels, C, toler):
        self.data = data  # 样本数据
        self.labels = labels  # 样本标签
        self.C = C  # 软间隔参数
        self.toler = toler  # 停止阈值
        self.nums = data.shape[0]  # 样本数量
        self.alphas = np.zeros(self.nums)  # #存放每个样本点的a值
        self.b = 0
        self.w = np.zeros(data.shape[1])
        #  用于缓存误差E，每个样本点对应一个Ei值，第一列为标识符，第二列存放值
        self.cache = np.zeros((self.nums, 2))
        self.K = np.zeros((self.nums, self.nums))  # 存放核函数计算结果
        for i in range(0, self.nums):
            self.K[:, i] = kernel(self.data, self.data[i, :])  # 核函数计算


def calE(i, ps):  # 计算误差E
    # np.multiply之后得到n维向量,在与核函数计算结果第i列相乘+b得到预测值fx
    fx = np.dot(np.multiply(ps.alphas, ps.labels), ps.K[:, i]) + ps.b
    # 误差值Ek
    E = fx - ps.labels[i]
    return E


# 根据SVM算法中的约束条件的分析，对获取的alpha_j进行截取操作
def clip_alpha(aj, H, L):
    if aj > H:
        aj = H
    if aj < L:
        aj = L
    return aj


def select_aj(i, ps, Ei):
    maxK = -1  # 保存临时最大索引
    maxDeltaE = 0  # 保存临时最大差值
    Ej = 0  # 保存误差值Ej
    # Ei保存到缓存中，1表示可用
    ps.cache[i] = np.array([1, Ei])
    # 获取所有有效的Ek值对应的索引
    valid_cache = np.where(ps.cache[:, 0] != 0)[0]  # 找到缓存中第一列非0，对应的有效误差值E的索引
    if len(valid_cache) > 1:  # 如果有效误差缓存长度大于1,则正常进行获取j值，否则使用selectJradn方法选取一个随机J值
        for k in valid_cache:
            if k == i:
                continue
            # 计算误差E，对比获取最大差值
            Ek = calE(k, ps)
            deltaE = abs(Ei - Ek)
            if deltaE > maxDeltaE:  # 更新Ej及其索引
                maxK = k
                maxDeltaE = deltaE
                Ej = Ek
        return maxK, Ej  # 返回aj的位置，及其误差Ej
    else:  # 无有效误差缓存，则随机选取一个索引
        j = i
        while j == i:
            j = random.randint(0, ps.nums - 1)  # 从0~m中随机选取一个数
        Ej = calE(j, ps)  # 计算对应误差E
        return j, Ej


# SMO内层循环
def innerL(i, ps):  # 参数ps：SMO相关参数SMO_parameter
    # 先会检查ai是否满足KKT条件，若不满足，会随机选择aj优化，更新ai，aj，b
    Ei = calE(i, ps)  # #计算E值，用于下方KKT条件
    # 判断是否满足KKT条件
    if ((ps.labels[i] * Ei < -ps.toler) and (ps.alphas[i] < ps.C)) or \
            ((ps.labels[i] * Ei > ps.toler) and (ps.alphas[i] > 0)):
        j, Ej = select_aj(i, ps, Ei)  # 随机选取aj，并返回其E值
        ai_old = ps.alphas[i].copy()  # 存放alpha_i
        aj_old = ps.alphas[j].copy()  # 存放alpha_j
        if ps.labels[i] != ps.labels[j]:  # 数据i,j所属标签相同
            L = max(0, aj_old - ai_old)
            H = min(ps.C, ps.C + aj_old - ai_old)
        else:  # 数据i,j所属不同标签
            L = max(0, aj_old + ai_old - ps.C)
            H = min(ps.C, aj_old + ai_old)
        if L == H:  # L==H,则返回0，不进行改变alpha
            return 0
        # 计算η=k_11+k_22-2k_12
        eta = ps.K[i, i] + ps.K[j, j] - 2.0 * ps.K[i][j]

        if eta <= 0:
            return 0
        # 更新aj，并更新对应的误差Ej
        ps.alphas[j] += ps.labels[j] * (Ei - Ej) / eta
        ps.alphas[j] = clip_alpha(ps.alphas[j], H, L)
        ps.cache[j] = np.array([1, calE(j, ps)])  # 更新误差Ej
        # 判断aj是否有足够的变化,变化不明显就不更新ai，直接返回
        if abs(ps.alphas[j] - aj_old) < ps.toler:
            return 0
        # 更新ai和误差Ei
        ps.alphas[i] += ps.labels[i] * ps.labels[j] * (aj_old - ps.alphas[j])
        ps.cache[i] = np.array([1, calE(i, ps)])  # 更新误差Ei
        # 更新b
        b1 = ps.b - Ei - ps.labels[i] * (ps.alphas[i] - ai_old) * ps.K[i, i] - ps.labels[j] * (ps.alphas[j] - aj_old) * \
             ps.K[i][j]
        b2 = ps.b - Ej - ps.labels[i] * (ps.alphas[i] - ai_old) * ps.K[i, j] - ps.labels[j] * (ps.alphas[j] - aj_old) * \
             ps.K[j][j]
        # 1.当新值ai不在界上时(0<ai<C)，b_new的计算规则为：b_new=b1
        # 2.当新值alpha_2不在界上时(0 < alpha_2 < C)，b_new的计算规则为：b_new = b2
        # 3.否则当alpha_1和alpha_2都不在界上时，b_new = 1/2(b1+b2)
        if ps.alphas[i] > 0 and ps.alphas[i] < ps.C:  # 当新的ai，0<ai<C
            ps.b = b1
        elif ps.alphas[j] > 0 and ps.alphas[j] < ps.C:  # 当新的aj，0<aj<C
            ps.b = b2
        else:
            ps.b = (b1 + b2) / 2.0
        return 1
    return 0  # 没有违背KKT条件


def SMO(ps, step,C):  # 参数ps：SMO相关参数SMO_parameter
    k = 1
    entire_set = True  # 标志是否应该遍历整个数据集
    alpha_pairs_changed = 0  # 一次循环中a更新的次数
    # 开始进行迭代
    # and右侧表示上一次循环，是在整个数据集中遍历，且没有a值更新过，则退出
    while (k <= step) and ((alpha_pairs_changed > 0) or entire_set):
        alpha_pairs_changed = 0
        if entire_set:
            for i in range(0, ps.nums):
                alpha_pairs_changed += innerL(i, ps)
            k += 1
        else:  # 遍历非边界数据
            nonBounds = np.where((ps.alphas > 0) & (ps.alphas < C))[0]  # 获取满足条件的a的索引
            for index in nonBounds:  # 开始遍历
                alpha_pairs_changed += innerL(index, ps)
            k += 1
        # 当遍历非边界数据后，a更新了则会继续遍历非边界数据，直到a无变化
        if entire_set:
            # 本次遍历了完整数据集，下次遍历费边界数据
            entire_set = False
        elif alpha_pairs_changed == 0:
            # 本次遍历了非边界数据,且a未改变，下次遍历完整数据
            entire_set = True


def cal_W(ps):  # 计算w
    for i in range(0, ps.nums):
        ps.w += ps.alphas[i] * ps.data[i] * ps.labels[i]


# 预测样本分类
def predict(data, labels, SMO_dict):
    count = 0
    total = len(data)
    for k in range(0, len(data)):  # 遍历每个样本
        ct = [0 for i in range(0, 10)]  # 记录该样本属于哪个标签次数
        for i in range(0, 9):
            for j in range(i + 1, 10):  # 判断该样本属于分类i还是j
                ps = SMO_dict[str(i) + str(j)]
                c = np.sign(np.dot(data[k], ps.w) + ps.b)
                if c == 1:
                    ct[i] += 1
                elif c == -1:
                    ct[j] += 1
        m = ct.index(max(ct))  # 找到次数最多的标签
        if (m == labels[k]):
            count += 1
    print(f"样本数{total},正确预测数{count},准确率为{100.0 * count / total}%")
