"""
-*- coding: utf-8 -*-
@Time :  2022-04-01 22:21
@Author : nanfang
"""
import os
import struct
from work.Machine_learning.PCA_SVM_MNIST.PCA import *
from work.Machine_learning.PCA_SVM_MNIST.SVM import *

def load_mnist(size, path, kind='train'):
    """
    加载MINIST数据集
    :param size: 加载数据集的大小
    :param path: 本地文件存放路径
    :param kind: train表示加载训练集，test表示加载测试集
    :return:
    """
    if kind == "test":
        kind = 't10k'
    labels_path = os.path.join(path, '%s-labels-idx1-ubyte' % kind)
    images_path = os.path.join(path, '%s-images-idx3-ubyte' % kind)
    with open(labels_path, 'rb') as lbpath:
        magic, n = struct.unpack('>II', lbpath.read(8))
        labels = np.fromfile(lbpath, dtype=np.uint8)
    with open(images_path, 'rb') as imgpath:
        magic, num, rows, cols = struct.unpack('>IIII', imgpath.read(16))
        images = np.fromfile(imgpath, dtype=np.uint8).reshape(len(labels), 784)
    return images[:size], labels[:size]


if __name__ == '__main__':
    DATA_PATH = '../../../dataset/mnist/MNIST/raw'  # 数据在本地的地址
    DATA_SIZE = 200  # 抽取的数据个数
    K = 50  # 表示压缩的维度
    C = 20  # 软间隔参数
    toler = 0.00001  # 停止阈值
    step = 30  # 迭代步长
    # 加载训练集
    train_imgs, train_labels = load_mnist(DATA_SIZE, DATA_PATH, kind='train')
    # 加载测试集
    test_imgs, test_labels = load_mnist(DATA_SIZE, DATA_PATH, kind='test')
    # 利用PCA对数据进行降维
    train_imgs_low, test_imgs_low = PCA_my(train_imgs, test_imgs, K)
    # 利用SVM对数据进行分类
    train_imgs = classify(train_imgs_low, train_labels)
    test_imgs = classify(test_imgs_low, test_labels)

    # 一对一，每组不同标签，计算一个SMO，共45个SMO
    SMO_dict = dict()  # key：由两个标签对应实际数字组成，value：存放对应SMO相关参数
    # 总共需要分0~9的类别
    for i in range(0, 9):
        for j in range(i + 1, 10):
            train_data = list(train_imgs[i])  # 存放标签为i,j的数据
            labels = [1 for k in range(0, len(train_imgs[i]))]  # 记录i,j对应标签，标签i改为标签1
            train_data.extend(list(train_imgs[j]))
            labels.extend([-1 for k in range(0, len(train_imgs[j]))])
            SMO_dict[str(i) + str(j)] = SMO_my(np.array(train_data), labels, C, toler)  # 初始化用于i，j分类的SMO的相关参数
            print(f"开始训练分类标签{i},{j}")
            SMO(SMO_dict[str(i) + str(j)], step,C)  # 执行用于i，j分类的SMO
            cal_W(SMO_dict[str(i) + str(j)])  # 计算w

    print("测试集准确率:")
    predict(test_imgs_low, test_labels, SMO_dict)
