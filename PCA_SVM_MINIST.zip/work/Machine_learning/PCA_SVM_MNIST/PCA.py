"""
-*- coding: utf-8 -*-
@Time :  2022-04-01 22:19
@Author : nanfang
"""
import numpy as np


def PCA_my(train_imgs, test_imgs, k):
    """
    自己实现的PCA，用来对数据进行降维
    :param train_imgs:  np.array([[]])  训练数据
    :param test_imgs:   np.array([[]])  测试数据
    :param k:  降低的维度
    :return:
    """
    n, w = train_imgs.shape
    X = train_imgs - train_imgs.mean(axis=0)  # 去中心化
    Mat = np.dot(X.T, X) / n  # 得到 X * X_T
    # 求 X * X_T 的前k大特征向量
    eigvals, vecs = np.linalg.eig(Mat)  # 注意求出的eigvals是特征值，vecs是标准化后的特征向量
    indexs = np.argsort(eigvals)  # 从小到大的顺序排列，值为以前数据所在的位置
    # 编码矩阵 D 是前k大特征向量组成的矩阵(正交矩阵)——topk_evecs
    v = vecs[:, indexs[:-k - 1:-1]]
    train_imgs_low = np.dot(X, v.real) / 100
    print("train_imgs_low.shape:", train_imgs_low.shape)
    # 对测试数据进行降维
    X = test_imgs - train_imgs.mean(axis=0)  # 去中心化
    test_imgs_low = np.dot(X, v.real) / 100
    print("test_imgs_low.shape:", test_imgs_low.shape)
    return train_imgs_low.real, test_imgs_low.real
